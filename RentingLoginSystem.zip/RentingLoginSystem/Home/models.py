from django.db import models

class Sign_up(models.Model):
    GENDER_CHOICES = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    ]
    
    customer_firstname = models.CharField(max_length=100)
    customer_lastname = models.CharField(max_length=100)
    customer_dob = models.DateField()
    customer_gender = models.CharField(max_length=6, choices=GENDER_CHOICES)
    customer_mobileno = models.CharField(max_length=15)
    customer_email = models.EmailField()
    customer_password = models.CharField(max_length=128)
    customer_address = models.TextField()
    customer_city = models.CharField(max_length=100)
    customer_state = models.CharField(max_length=100)
    customer_country = models.CharField(max_length=100)
    customer_pincode = models.CharField(max_length=20)
    customer_license = models.FileField(upload_to='licenses/')
    
    def __str__(self):
        return f"{self.customer_firstname} {self.customer_lastname}"
