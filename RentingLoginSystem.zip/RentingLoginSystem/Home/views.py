from django.contrib.auth.hashers import check_password
from django.contrib.auth.hashers import make_password
from django.shortcuts import render,redirect
from django.contrib import messages
from .models import *

# Create your views here.

def registration(request):
    r = Sign_up.objects.all()
    if request.method == 'POST':
        customer_firstname = request.POST['customer_firstname']
        customer_lastname = request.POST['customer_lastname']
        customer_dob = request.POST['customer_dob']
        customer_gender = request.POST['customer_gender']
        customer_mobileno = request.POST['customer_mobileno']
        customer_email = request.POST['customer_email']
        customer_password = make_password(request.POST['customer_password'])  # Hash the password
        customer_address = request.POST['customer_address']
        customer_city = request.POST['customer_city']
        customer_state = request.POST['customer_state']
        customer_country = request.POST['customer_country']
        customer_pincode = request.POST['customer_pincode']
        customer_license = request.FILES['customer_license']
        
        r = Sign_up.objects.create(
            customer_firstname=customer_firstname,
            customer_lastname=customer_lastname,
            customer_dob=customer_dob,
            customer_gender=customer_gender,
            customer_mobileno=customer_mobileno,
            customer_email=customer_email,
            customer_password=customer_password,
            customer_address=customer_address,
            customer_city=customer_city,
            customer_state=customer_state,
            customer_country=customer_country,
            customer_pincode=customer_pincode,
            customer_license=customer_license
        )
        messages.info(request, 'CUSTOMER REGISTRATION SUCCESS PLEASE LOGIN')
        return redirect('http://127.0.0.1:8000/')
    
    context = {
        'r': r
    }
    return render(request, 'user_registration.html', context)
    # return render(request,'user_registration.html')

def index(request):
    if request.method == 'POST':
        customer_email = request.POST['customer_email']
        customer_password = request.POST['customer_password']
        
        users = Sign_up.objects.filter(customer_email=customer_email)
        if users.count() == 1:
            user = users.first()
            if check_password(customer_password, user.customer_password):
                # messages.success(request, 'Login successful')
                return redirect('/User Dashboard/')  # Redirect to the desired page after login
            else:
                messages.error(request, 'Invalid password')
        elif users.count() > 1:
            messages.error(request, 'Multiple accounts with this email found. Please contact support.')
        else:
            messages.error(request, 'User does not exist')
    
    return render(request, 'index.html')

def user_dashboard(request):
    return render(request, 'dashboard.html')
  


