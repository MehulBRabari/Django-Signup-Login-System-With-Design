from django.urls import path
from.import views

urlpatterns = [
    path('', views.index),
    path('User_registration/', views.registration),
    path('User Dashboard/', views.user_dashboard),

]
